import { useEffect } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SocialProof from "./components/SocialProof";
import HowItWorks from "./components/HowItWorks";
import Features from "./components/Features";
import Pricing from "./components/Pricing";
import Testimonials from "./components/Testimonials";
import FAQ from "./components/FAQ";
import FinalCTA from "./components/FinalCTA";
import Footer from "./components/Footer";

export default function App() {
  
  // Register active Intersection Observer to reveal scrolling items
  useEffect(() => {
    const revealCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    };

    const observer = new IntersectionObserver(revealCallback, {
      threshold: 0.08,
      rootMargin: "0px 0px -40px 0px"
    });

    const scrollElements = document.querySelectorAll(".scroll-reveal");
    scrollElements.forEach((el) => observer.observe(el));

    // Stagger animation helpers for grid cards
    const featureCards = document.querySelectorAll("#features .scroll-reveal");
    featureCards.forEach((card, index) => {
      (card as HTMLElement).style.transitionDelay = `${(index % 3) * 150}ms`;
    });

    const pricingCards = document.querySelectorAll("#pricing .scroll-reveal");
    pricingCards.forEach((card, index) => {
      (card as HTMLElement).style.transitionDelay = `${index * 150}ms`;
    });

    const stepCards = document.querySelectorAll("#about .scroll-reveal");
    stepCards.forEach((card, index) => {
      (card as HTMLElement).style.transitionDelay = `${index * 150}ms`;
    });

    return () => {
      scrollElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white selection:bg-[#6C63FF]/30 selection:text-[#00D4FF] relative flex flex-col font-sans overflow-hidden">
      
      {/* Mesh decorative patterns */}
      <div className="absolute top-[800px] right-0 w-[500px] h-[500px] bg-[#6C63FF]/5 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute top-[1800px] left-0 w-[400px] h-[400px] bg-[#00D4FF]/3 rounded-full blur-[135px] pointer-events-none"></div>
      <div className="absolute top-[3200px] right-10 w-[600px] h-[600px] bg-[#6C63FF]/4 rounded-full blur-[150px] pointer-events-none"></div>

      {/* 1. Sticky Navbar */}
      <Navbar />

      <main className="flex-grow">
        
        {/* 2. Primary Hero Section */}
        <Hero />

        {/* 3. Social Proof Gray Logos */}
        <SocialProof />

        {/* 4. How It Works sequence */}
        <HowItWorks />

        {/* 5. Features lists grid */}
        <Features />

        {/* 6. Pricing tables & switcher */}
        <Pricing />

        {/* 7. Client Testimonials */}
        <Testimonials />

        {/* 8. Frequently Asked Questions */}
        <FAQ />

        {/* 9. Glowing Action Form (CTA) */}
        <FinalCTA />

      </main>

      {/* 10. Social Logo Sitemap Footer */}
      <Footer />

    </div>
  );
}
