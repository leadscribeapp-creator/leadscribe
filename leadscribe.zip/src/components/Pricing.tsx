import { useState } from "react";
import { Check } from "lucide-react";

export default function Pricing() {
  const [isAnnual, setIsAnnual] = useState(false);

  // Prices: starter ($49, annual -20% is $39), growth ($99, annual -20% is $79), agency ($249, annual -20% is $199)
  const plans = [
    {
      id: "starter",
      name: "Starter",
      monthlyPrice: 49,
      annualPrice: 39,
      subtitle: "Perfect for solopreneurs seeking initial pipeline",
      features: [
        "100 AI messages/month",
        "Lead CRM (up to 500 leads)",
        "Email outreach channel",
        "Basic response analytics",
        "Standard email support"
      ],
      isPopular: false,
      buttonText: "Start Free Trial",
      isOutlined: true,
      link: "mailto:hello@leadscribe.app?subject=LeadScribe%20Starter%20Trial"
    },
    {
      id: "growth",
      name: "Growth",
      monthlyPrice: 99,
      annualPrice: 79,
      subtitle: "For growing high-performing sales teams",
      features: [
        "500 AI messages/month",
        "Unlimited target leads",
        "Multi-channel outreach (Email, LinkedIn)",
        "Advanced pipeline analytics",
        "Priority Slack support",
        "API access keys"
      ],
      isPopular: true,
      buttonText: "Start Free Trial",
      isOutlined: false,
      link: "mailto:hello@leadscribe.app?subject=LeadScribe%20Growth%20Trial"
    },
    {
      id: "agency",
      name: "Agency",
      monthlyPrice: 249,
      annualPrice: 199,
      subtitle: "For agencies & multi-client enterprise teams",
      features: [
        "Unlimited AI messages",
        "White-label outbound option",
        "Custom workflow integrations",
        "Dedicated account manager",
        "99.9% Support SLA guarantee",
        "Full team onboarding & training"
      ],
      isPopular: false,
      buttonText: "Contact Sales",
      isOutlined: true,
      link: "mailto:hello@leadscribe.app?subject=LeadScribe%20Agency%20Sales%20Inquiry"
    }
  ];

  return (
    <section id="pricing" className="py-24 md:py-32 bg-[#111118]/60 relative border-t border-white/5 scroll-mt-20">
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[#00D4FF]/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header content */}
        <div className="text-center max-w-2xl mx-auto mb-16 scroll-reveal">
          <span className="text-xs font-bold tracking-widest text-[#6C63FF] uppercase px-3 py-1 rounded-full bg-[#6C63FF]/10 mb-4 inline-block">
            Flexible Plans
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mt-1 mb-5">
            Simple, Transparent Pricing
          </h2>
          <p className="text-[#8B8B9E] text-base sm:text-lg">
            Start free, scale when ready. Select the tier that matches your monthly outbound needs perfectly.
          </p>

          {/* Pricing Switcher Toggle */}
          <div className="flex items-center justify-center gap-4 mt-10">
            <span className={`text-sm font-semibold transition-colors duration-200 ${!isAnnual ? "text-white" : "text-[#8B8B9E]"}`}>
              Monthly billing
            </span>
            
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative w-14 h-8 bg-[#16161F] border border-white/10 rounded-full p-1 transition-all duration-300 hover:border-[#6C63FF]/50"
              aria-label="Toggle annual pricing discout"
            >
              <div
                className={`w-6 h-6 rounded-full bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] shadow-md transition-all duration-300 transform ${
                  isAnnual ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>

            <span className={`text-sm font-semibold transition-colors duration-200 flex items-center gap-1.5 ${isAnnual ? "text-[#00D4FF]" : "text-[#8B8B9E]"}`}>
              Annual billing
              <span className="text-[10px] bg-[#00D4FF]/10 text-[#00D4FF] border border-[#00D4FF]/20 px-2 py-0.5 rounded-full font-bold">
                Save 20%
              </span>
            </span>
          </div>

        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch select-none">
          {plans.map((plan, idx) => {
            const displayPrice = isAnnual ? plan.annualPrice : plan.monthlyPrice;
            const savings = isAnnual ? (plan.monthlyPrice - plan.annualPrice) * 12 : 0;

            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl p-8 flex flex-col justify-between transition-all duration-300 hover:translate-y-[-8px] scroll-reveal ${
                  plan.isPopular
                    ? "bg-[#16161F] border-2 border-[#6C63FF]/60 shadow-[0_15px_40px_-15px_rgba(108,99,255,0.25)] lg:scale-105 z-10"
                    : "bg-[#16161F]/40 border border-white/5 shadow-xl hover:border-white/10"
                }`}
                style={{ transitionDelay: `${idx * 150}ms` }}
              >
                
                {/* Popular Badge */}
                {plan.isPopular && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] text-white text-xs font-extrabold tracking-wider py-1 px-4 rounded-full shadow-lg">
                    MOST POPULAR
                  </span>
                )}

                <div>
                  
                  {/* Tier Title */}
                  <h3 className="text-xl font-extrabold text-white mb-2">{plan.name}</h3>
                  <p className="text-xs text-[#8B8B9E] mb-6 leading-relaxed">{plan.subtitle}</p>

                  {/* Price */}
                  <div className="flex items-baseline gap-1 mb-8">
                    <span className="text-4xl sm:text-5xl font-black text-white tracking-tight">
                      ${displayPrice}
                    </span>
                    <span className="text-[#8B8B9E] text-sm font-medium">/month</span>
                  </div>

                  {/* Features List */}
                  <div className="border-t border-white/5 pt-6 mb-8">
                    <h4 className="text-xs font-bold text-white/40 tracking-wider uppercase mb-4">WHAT'S INCLUDED</h4>
                    <ul className="space-y-3.5">
                      {plan.features.map((feature, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-2.5 text-sm text-white/80">
                          <span className="h-5 w-5 rounded-full bg-[#00C896]/10 flex items-center justify-center shrink-0">
                            <Check className="h-3 w-3 text-[#00C896] stroke-[3.5px]" />
                          </span>
                          <span className="leading-tight">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* Button actions */}
                <div className="mt-auto">
                  
                  {isAnnual && savings > 0 && (
                    <div className="text-center text-[11px] text-[#00D4FF] font-semibold mb-3">
                      Billed annually (Saves ${savings}/year)
                    </div>
                  )}

                  <a
                    href={plan.link}
                    className={`block w-full py-4 px-6 rounded-2xl font-bold text-sm text-center transition-all duration-300 ${
                      plan.isPopular
                        ? "gradient-bg text-white shadow-[0_4px_15px_rgba(108,99,255,0.4)] hover:shadow-[0_4px_25px_rgba(108,99,255,0.6)] hover:scale-[1.03]"
                        : "bg-transparent border border-white/10 text-white hover:bg-white/5 hover:border-white/30 hover:scale-[1.01]"
                    }`}
                  >
                    {plan.buttonText}
                  </a>

                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
