import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLinkClick = (id: string) => {
    setIsOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      id="navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-white/5 backdrop-blur-xl ${
        isScrolled ? "bg-[#0A0A0F]/90 py-4 shadow-lg shadow-[#000000]/50" : "bg-[#0A0A0F]/50 py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo */}
        <a
          href="#"
          className="text-2xl font-black tracking-tight text-white flex items-center gap-1 select-none"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          LeadScribe<span className="text-[#6C63FF] text-[2.5rem] leading-[0] -ml-0.5 animate-pulse">.</span>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          <button
            onClick={() => handleLinkClick("features")}
            className="text-[#8B8B9E] hover:text-white transition-colors text-sm font-medium relative group py-1"
          >
            Features
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] transition-all duration-300 group-hover:w-full"></span>
          </button>
          
          <button
            onClick={() => handleLinkClick("pricing")}
            className="text-[#8B8B9E] hover:text-white transition-colors text-sm font-medium relative group py-1"
          >
            Pricing
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] transition-all duration-300 group-hover:w-full"></span>
          </button>
          
          <button
            onClick={() => handleLinkClick("about")}
            className="text-[#8B8B9E] hover:text-white transition-colors text-sm font-medium relative group py-1"
          >
            About
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] transition-all duration-300 group-hover:w-full"></span>
          </button>
        </div>

        {/* Desktop CTA */}
        <div className="hidden md:block">
          <a
            href="mailto:hello@leadscribe.app"
            className="inline-flex items-center justify-center bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] text-white px-6 py-2.5 rounded-full font-semibold hover:scale-105 transition-all duration-300 shadow-lg shadow-[#6C63FF]/20"
          >
            Start Free Trial
          </a>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 text-[#8B8B9E] hover:text-white focus:outline-none"
          aria-label="Toggle Menu"
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu panel */}
      <div
        className={`md:hidden absolute top-full left-0 right-0 bg-[#0A0A0F] border-b border-white/5 transition-all duration-300 overflow-hidden ${
          isOpen ? "max-h-screen opacity-100 py-6 px-6" : "max-h-0 opacity-0 py-0 px-6"
        }`}
      >
        <div className="flex flex-col gap-5 text-center">
          <button
            onClick={() => handleLinkClick("features")}
            className="text-[#8B8B9E] hover:text-white font-medium text-base py-2 transition-colors"
          >
            Features
          </button>
          <button
            onClick={() => handleLinkClick("pricing")}
            className="text-[#8B8B9E] hover:text-white font-medium text-base py-2 transition-colors"
          >
            Pricing
          </button>
          <button
            onClick={() => handleLinkClick("about")}
            className="text-[#8B8B9E] hover:text-white font-medium text-base py-2 transition-colors"
          >
            About
          </button>
          <div className="border-t border-white/5 pt-4">
            <a
              href="mailto:hello@leadscribe.app"
              className="block w-full text-center py-3 px-6 rounded-full font-semibold text-white bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] hover:shadow-[0_0_20px_0_rgba(108,99,255,0.4)] transition-all duration-300"
            >
              Start Free Trial
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}
