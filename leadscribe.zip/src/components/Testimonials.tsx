import { Star, Quote } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      quote: "LeadScribe saved our team 20 hours per week. The AI writes better cold emails than we ever did. Highly recommend to any outbound team.",
      author: "Sarah M.",
      role: "Marketing Director",
      agency: "AeroMedia",
      stars: 5,
      avatarInitials: "SM"
    },
    {
      quote: "We went from 5% to 23% reply rate in just 2 weeks after switching to LeadScribe. The level of personalization is incredible.",
      author: "Ahmed K.",
      role: "Sales Director",
      agency: "Vertex Labs",
      stars: 5,
      avatarInitials: "AK"
    },
    {
      quote: "Best investment for our B2B sales agency. Our clients love the results, and booking meetings has never been this painless.",
      author: "Maria L.",
      role: "Agency Founder",
      agency: "SaaSGrowth.io",
      stars: 5,
      avatarInitials: "ML"
    }
  ];

  return (
    <section id="testimonials" className="py-24 md:py-32 bg-[#0A0A0F] relative overflow-hidden">
      {/* Background glow lines */}
      <div className="absolute bottom-10 left-10 w-[300px] h-[300px] bg-[#6C63FF]/5 rounded-full blur-[80px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header center text */}
        <div className="text-center max-w-2xl mx-auto mb-20 scroll-reveal">
          <span className="text-xs font-bold tracking-widest text-[#00C896] uppercase px-3 py-1 rounded-full bg-[#00C896]/10 mb-4 inline-block">
            Customer Success
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mt-1 mb-5">
            What Our Customers Say
          </h2>
          <p className="text-[#8B8B9E] text-base sm:text-lg">
            Hear from B2B sales teams, agencies, and lone founders who converted their outreach from ignored to accepted.
          </p>
        </div>

        {/* Dynamic Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="bg-[#16161F]/40 border border-white/5 p-8 rounded-3xl flex flex-col justify-between hover:border-[#6C63FF]/30 hover:shadow-[0_10px_30px_rgba(108,99,255,0.05)] transition-all duration-300 transform hover:translate-y-[-4px] group scroll-reveal"
              style={{ transitionDelay: `${idx * 150}ms` }}
            >
              
              {/* Outer top quote block */}
              <div>
                
                {/* Five gold stars */}
                <div className="flex items-center gap-1 mb-6">
                  {[...Array(t.stars)].map((_, sIdx) => (
                    <Star
                      key={sIdx}
                      className="h-4 w-4 fill-[#FFD700] text-[#FFD700]"
                    />
                  ))}
                </div>

                {/* Quote details */}
                <span className="block mb-6 relative">
                  <Quote className="absolute -top-3 -left-3 h-8 w-8 text-white/[0.03] rotate-180" />
                  <p className="text-white/90 text-sm leading-relaxed relative z-10 italic">
                    "{t.quote}"
                  </p>
                </span>

              </div>

              {/* Author Footer profile details */}
              <div className="flex items-center gap-3.5 pt-6 border-t border-white/5 mt-6">
                
                {/* Avatar circle */}
                <div className="h-10 w-10 bg-gradient-to-br from-[#1E1E2F] to-[#252538] border border-white/10 rounded-full flex items-center justify-center font-bold text-xs text-[#00D4FF]">
                  {t.avatarInitials}
                </div>

                {/* Profile details */}
                <div>
                  <div className="text-sm font-bold text-white group-hover:text-[#6C63FF] transition-colors">
                    {t.author}
                  </div>
                  <div className="text-[11px] text-[#8B8B9E] font-medium leading-none mt-1">
                    {t.role} • <span className="text-white/55 font-mono">{t.agency}</span>
                  </div>
                </div>

              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
