import { useState, useEffect, useRef } from "react";
import { ArrowRight, Play, Zap, BarChart3, Mail, Sparkles, Check } from "lucide-react";

export default function Hero() {
  const [activeTab, setActiveTab] = useState<"email" | "linkedin">("email");
  const [typedText, setTypedText] = useState("");
  const [step, setStep] = useState(0); // 0: Idle/Target loaded, 1: Generating, 2: Done typing
  const [speedVal, setSpeedVal] = useState(30);

  // Counter states for the 3 float stats cards
  const [count1, setCount1] = useState(1);
  const [count2, setCount2] = useState(1);
  const [count3, setCount3] = useState(1);

  const samples = [
    {
      to: "Sarah Jenkins",
      company: "Acme Growth",
      role: "VP of Marketing",
      about: "scaling credit card distribution channels",
      subject: "Personalized strategy for Sarah @ Acme Growth",
      body: "Hi Sarah,\n\nI read your recent post about scaling credit card distribution channels at Acme Growth. Phenomenal insights! \n\nI analyzed your current onboarding flow and wrote a custom outbound sequence that could lift conversions by 15%. I'd love to partner up and send the full brief. \n\nBest,\nYour Team"
    },
    {
      to: "Devon Carter",
      company: "SaaSify Co",
      role: "Sales Operations Lead",
      about: "hiring three B2B account executives in London",
      subject: "outbound pipeline ideas for SaaSify Co",
      body: "Hey Devon,\n\nSince SaaSify Co is currently hiring three B2B account executives in London, I wanted to share a custom list of 50 local hyper-targeted leads matching your exact enterprise buyer profile.\n\nLeadScribe can draft personalized messages for all 50 automatically in under 60 seconds. Let's sync up!\n\nCheers,\nAlex"
    }
  ];

  const [sampleIdx, setSampleIdx] = useState(0);
  const currentSample = samples[sampleIdx];

  // Counter animations on mount
  useEffect(() => {
    const duration = 1500; // ms
    const stepTime = 30;
    const steps = duration / stepTime;

    // "10x Faster" - counts to 10
    const target1 = 10;
    const inc1 = target1 / steps;
    // "500+ Messages" - counts to 500
    const target2 = 500;
    const inc2 = target2 / steps;
    // "89% Open Rate" - counts to 89
    const target3 = 89;
    const inc3 = target3 / steps;

    let currentStep = 0;
    const timer = setInterval(() => {
      currentStep++;
      if (currentStep >= steps) {
        setCount1(target1);
        setCount2(target2);
        setCount3(target3);
        clearInterval(timer);
      } else {
        setCount1(Math.min(target1, Math.round(currentStep * inc1)));
        setCount2(Math.min(target2, Math.round(currentStep * inc2)));
        setCount3(Math.min(target3, Math.round(currentStep * inc3)));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, []);

  // Typewriter effect for the mock editor
  useEffect(() => {
    let timer: NodeJS.Timeout;
    const fullText = `Subject: ${currentSample.subject}\n\n${currentSample.body}`;
    
    // Set status to "generating"
    setStep(1);
    setTypedText("");
    
    let currentIndex = 0;
    const typeNextChar = () => {
      if (currentIndex < fullText.length) {
        setTypedText(fullText.substring(0, currentIndex + 1));
        currentIndex++;
        timer = setTimeout(typeNextChar, speedVal);
      } else {
        setStep(2); // Done
        // Wait 4 seconds, then start next sample
        timer = setTimeout(() => {
          setSampleIdx((prev) => (prev + 1) % samples.length);
        }, 4000);
      }
    };

    // Delay start of typing slightly to simulate thinking
    const delayTimer = setTimeout(() => {
      typeNextChar();
    }, 1200);

    return () => {
      clearTimeout(timer);
      clearTimeout(delayTimer);
    };
  }, [sampleIdx]);

  const handleWatchDemoClick = () => {
    alert("Demo coming soon! Contact us at hello@leadscribe.app");
  };

  return (
    <section className="relative pt-32 pb-24 md:pt-40 md:pb-36 overflow-hidden animated-bg">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#6C63FF]/15 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute top-1/3 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-[#00D4FF]/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
        
        {/* Left column: Text Content */}
        <div className="lg:col-span-7 flex flex-col items-center lg:items-start text-center lg:text-left">
          
          {/* Badge Above */}
          <div className="inline-flex items-center px-4 py-2 rounded-full border border-[#6C63FF]/30 bg-[#6C63FF]/10 text-xs font-bold uppercase tracking-widest text-[#00D4FF] shadow-[0_0_15px_rgba(108,99,255,0.15)] mb-6 animate-pulse select-none">
            🤖 AI-Powered Outreach Platform
          </div>

          {/* Title */}
          <h1 className="text-4xl sm:text-5xl md:text-[72px] font-[800] leading-[1.05] tracking-tighter text-white mb-6">
            Turn Prospects Into <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#6C63FF] to-[#00D4FF]">Paying Clients</span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg md:text-xl text-[#8B8B9E] font-normal leading-relaxed max-w-xl mb-10">
            LeadScribe uses AI to write personalized outreach messages for every lead — automatically.
            Save hours, book more meetings, close more deals.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto mb-6">
            <a
              href="mailto:hello@leadscribe.app"
              className="w-full sm:w-auto text-center bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] text-white font-bold text-lg py-4 px-8 rounded-xl shadow-lg shadow-[#6C63FF]/20 hover:scale-105 hover:opacity-90 transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer"
            >
              Start Free Trial
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </a>

            <button
              onClick={handleWatchDemoClick}
              className="w-full sm:w-auto text-center bg-transparent hover:bg-white/5 text-white border border-white/20 font-bold text-lg py-4 px-8 rounded-xl hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2"
            >
              Watch Demo ▶️
            </button>
          </div>

          {/* Small feature confirmation line */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-2 text-[#8B8B9E] text-sm font-medium">
            <span className="flex items-center gap-1 text-[#00C896]">
              <Check className="h-4 w-4 stroke-[3px]" /> Free 14-day trial
            </span>
            <span className="flex items-center gap-1 text-[#00C896]">
              <Check className="h-4 w-4 stroke-[3px]" /> No credit card
            </span>
            <span className="flex items-center gap-1 text-[#00C896]">
              <Check className="h-4 w-4 stroke-[3px]" /> Cancel anytime
            </span>
          </div>

        </div>

        {/* Right column: Interactive Dashboard Mockup + Floats */}
        <div className="lg:col-span-5 relative w-full flex justify-center py-8">
            {/* Primary Dashboard Card mockup */}
          <div className="w-full max-w-[460px] bg-[#16161F] rounded-2xl border border-white/10 shadow-2xl overflow-hidden relative backdrop-blur-md">
            
            {/* Window control bar */}
            <div className="bg-[#111118] px-5 py-3 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-red-500/50"></span>
                <span className="w-3 h-3 rounded-full bg-yellow-500/50"></span>
                <span className="w-3 h-3 rounded-full bg-green-500/50"></span>
              </div>
              <div className="ml-4 text-[10px] text-[#8B8B9E] font-mono tracking-widest uppercase">
                AI WRITING MESSAGE...
              </div>
              <div className="w-12 h-1"></div>
            </div>

            {/* Dashboard Content */}
            <div className="p-5 flex flex-col gap-4">
              
              {/* Prospect Details Header */}
              <div className="bg-[#111118]/70 rounded-xl p-3 border border-white/5 flex items-center gap-3">
                <div className="h-9 w-9 bg-gradient-to-tr from-[#6C63FF] to-[#00D4FF] rounded-full flex items-center justify-center text-xs font-bold text-white shadow-md shadow-[#6C63FF]/20">
                  {currentSample.to.split(" ").map(n => n[0]).join("")}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-white flex items-center justify-between">
                    <span className="truncate">{currentSample.to}</span>
                    <span className="text-[10px] text-[#00D4FF] bg-[#00D4FF]/10 px-1.5 py-0.5 rounded font-mono font-medium">
                      B2B Match
                    </span>
                  </div>
                  <div className="text-[11px] text-[#8B8B9E] truncate">
                    {currentSample.role} • <span className="text-white/70">{currentSample.company}</span>
                  </div>
                </div>
              </div>

              {/* Status Indicator */}
              <div className="flex items-center justify-between text-xs py-1 border-b border-white/5 text-[#8B8B9E]">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5 text-[#00D4FF] animate-spin" />
                  <span className="font-medium text-white/90">
                    {step === 1 ? "AI Writing Message..." : "AI Writing Message Ready"}
                  </span>
                </div>
                <div className="text-[10px] font-mono select-none px-2 py-0.5 rounded bg-white/5 text-white/60">
                  {step === 1 ? "processing..." : "idle"}
                </div>
              </div>

              {/* Live typing area */}
              <div className="h-56 bg-[#0A0A0F] rounded-xl p-4 border border-white/5 overflow-y-auto font-mono text-sm text-white/90 leading-relaxed whitespace-pre-wrap select-none scrollbar-thin">
                {typedText}
                <span className="inline-block w-1.5 h-3 bg-[#08D5FF] ml-0.5 animate-pulse"></span>
              </div>

              {/* Action buttons list in mock */}
              <div className="flex items-center justify-between gap-3 pt-1">
                <div className="text-[10px] text-white/40 flex items-center gap-1">
                  <span>Channel:</span>
                  <span className="text-white/60 font-medium">Cold Email</span>
                </div>
                <a
                  href="mailto:hello@leadscribe.app"
                  className="bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] text-white text-[11px] font-bold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Mail className="h-3 w-3" />
                  Approve & Send
                </a>
              </div>

            </div>
          </div>

          {/* Floats Wrapper and positioning */}
          
          {/* Float Card 1: 10x Faster */}
          <div className="absolute top-1/4 -left-8 md:-left-12 translate-y-[-50%] bg-[#111118] border border-white/10 p-4 rounded-xl shadow-xl flex items-center gap-3 animate-float-slow backdrop-blur-md max-w-[170px] pointer-events-none z-20">
            <div className="w-10 h-10 bg-[#6C63FF]/20 rounded-lg flex items-center justify-center text-[#6C63FF]">
              ⚡
            </div>
            <div>
              <div className="text-lg font-bold text-white">{count1}x Faster</div>
              <div className="text-[10px] uppercase text-[#8B8B9E] tracking-tighter">Outreach Speed</div>
            </div>
          </div>

          {/* Float Card 2: 500+ Messages / Day */}
          <div className="absolute bottom-12 -left-4 md:-left-10 bg-[#111118] border border-white/10 p-4 rounded-xl shadow-xl flex items-center gap-3 animate-float-medium backdrop-blur-md max-w-[190px] pointer-events-none z-20">
            <div className="w-10 h-10 bg-[#00D4FF]/20 rounded-lg flex items-center justify-center text-[#00D4FF]">
              💼
            </div>
            <div>
              <div className="text-lg font-bold text-white">{count2}+ Daily</div>
              <div className="text-[10px] uppercase text-[#8B8B9E] tracking-tighter">Auto Custom Emails</div>
            </div>
          </div>

          {/* Float Card 3: 89% Open Rate */}
          <div className="absolute top-1/3 -right-6 md:-right-10 bg-[#111118] border border-white/10 p-4 rounded-xl shadow-xl flex items-center gap-3 animate-float-fast backdrop-blur-md max-w-[160px] pointer-events-none z-20">
            <div className="w-10 h-10 bg-[#00D4FF]/20 rounded-lg flex items-center justify-center text-[#00D4FF]">
              📈
            </div>
            <div>
              <div className="text-lg font-bold text-[#00D4FF]">{count3}%</div>
              <div className="text-[10px] uppercase text-[#8B8B9E] tracking-tighter font-medium">Avg. Open Rate</div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
