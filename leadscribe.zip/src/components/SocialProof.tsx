export default function SocialProof() {
  const companies = [
    { name: "Apex Global", desc: "Enterprise Tech" },
    { name: "SaaSify Inc", desc: "B2B SaaS" },
    { name: "Synergie Group", desc: "Ventures" },
    { name: "Zetta Digital", desc: "Agency" },
    { name: "Nova Marketing", desc: "Creatives" }
  ];

  return (
    <section className="py-12 bg-[#0A0A0F] border-t border-b border-white/5 relative z-10 scroll-reveal">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          
          {/* Label */}
          <div className="text-sm font-semibold tracking-wider text-[#8B8B9E] uppercase whitespace-nowrap lg:border-r lg:border-white/5 lg:pr-10">
            Trusted by teams at
          </div>
          
          {/* Companies Grid */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-y-8 gap-x-12 items-center justify-items-center w-full">
            {companies.map((company, index) => (
              <div
                key={index}
                className="flex flex-col items-center justify-center opacity-45 hover:opacity-85 transition-opacity duration-300 select-none group"
              >
                <div className="text-base font-extrabold text-white tracking-widest font-sans group-hover:text-[#6C63FF] transition-colors">
                  {company.name.toUpperCase()}
                </div>
                <div className="text-[9px] font-mono text-[#8B8B9E] tracking-widest mt-0.5">
                  {company.desc.toUpperCase()}
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}
