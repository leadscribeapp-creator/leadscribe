import { Twitter, Linkedin, Instagram, Mail, ArrowUp } from "lucide-react";

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLinkClick = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-[#0A0A0F] border-t border-white/5 pt-16 pb-12 relative z-10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start mb-16">
          
          {/* Brand Col */}
          <div className="col-span-1 md:col-span-5 flex flex-col items-start max-w-sm">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                handleScrollToTop();
              }}
              className="text-2xl font-black tracking-tight text-white flex items-center gap-1 select-none"
            >
              LeadScribe<span className="text-[#6C63FF] text-[2.5rem] leading-[0] -ml-0.5">.</span>
            </a>
            <p className="text-sm text-[#8B8B9E] font-normal mt-4 leading-relaxed">
              Leading the personalized outbound outreach revolution. Our AI produces custom high-converting sales sequences calibrated directly from client background details.
            </p>
          </div>

          {/* Links 1 */}
          <div className="col-span-1 md:col-span-3 flex flex-col gap-4">
            <h4 className="text-xs font-bold text-white tracking-wider uppercase">Product</h4>
            <div className="flex flex-col gap-2.5">
              <button
                onClick={() => handleLinkClick("features")}
                className="text-left text-sm text-[#8B8B9E] hover:text-[#00D4FF] transition-colors"
              >
                Features
              </button>
              <button
                onClick={() => handleLinkClick("pricing")}
                className="text-left text-sm text-[#8B8B9E] hover:text-[#00D4FF] transition-colors"
              >
                Pricing
              </button>
              <button
                onClick={() => handleLinkClick("faq")}
                className="text-left text-sm text-[#8B8B9E] hover:text-[#00D4FF] transition-colors"
                aria-label="Frequently Asked Questions"
              >
                Help & FAQ
              </button>
            </div>
          </div>

          {/* Links 2 */}
          <div className="col-span-1 md:col-span-2 flex flex-col gap-4">
            <h4 className="text-xs font-bold text-white tracking-wider uppercase">Legal</h4>
            <div className="flex flex-col gap-2.5">
              <a
                href="mailto:hello@leadscribe.app?subject=Privacy%20Policy%20Enquiry"
                className="text-sm text-[#8B8B9E] hover:text-[#00D4FF] transition-colors"
              >
                Privacy Policy
              </a>
              <a
                href="mailto:hello@leadscribe.app?subject=Terms%20of%20Service%20Enquiry"
                className="text-sm text-[#8B8B9E] hover:text-[#00D4FF] transition-colors"
              >
                Terms of Service
              </a>
            </div>
          </div>

          {/* Contact Support info */}
          <div className="col-span-1 md:col-span-2 flex flex-col gap-4 text-left">
            <h4 className="text-xs font-bold text-white tracking-wider uppercase">Inbound</h4>
            <a
              href="mailto:hello@leadscribe.app"
              className="text-sm text-[#8B8B9E] hover:text-white transition-colors flex items-center gap-1.5 font-semibold group"
            >
              <Mail className="h-4 w-4 text-[#6C63FF] group-hover:scale-110 transition-transform" />
              hello@leadscribe.app
            </a>
          </div>

        </div>

        {/* Outer footer base borders and contents */}
        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          
          {/* Copyright description */}
          <div className="text-xs text-[#8B8B9E] font-medium tracking-tight">
            © 2026 LeadScribe. All rights reserved. • Built for B2B.
          </div>

          {/* Social icons list and back-to-top buttons */}
          <div className="flex items-center gap-8">
            
            {/* Social profiles */}
            <div className="flex items-center gap-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-white/5 text-[#8B8B9E] hover:text-[#00D4FF] hover:bg-[#00D4FF]/10 transition-all duration-300"
                aria-label="LeadScribe Twitter Channel"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-white/5 text-[#8B8B9E] hover:text-[#00D4FF] hover:bg-[#00D4FF]/10 transition-all duration-300"
                aria-label="LeadScribe LinkedIn Profile"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-white/5 text-[#8B8B9E] hover:text-[#00D4FF] hover:bg-[#00D4FF]/10 transition-all duration-300"
                aria-label="LeadScribe Instagram Gallery"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="mailto:hello@leadscribe.app"
                className="p-2 rounded-xl bg-white/5 text-[#8B8B9E] hover:text-[#00D4FF] hover:bg-[#00D4FF]/10 transition-all duration-300"
                aria-label="Send direct mail to support team"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>

            {/* Back to top item */}
            <button
              onClick={handleScrollToTop}
              className="p-2.5 rounded-full bg-[#16161F] hover:bg-[#6C63FF] text-[#8B8B9E] hover:text-white transition-all duration-300 group border border-white/5 shadow-md flex items-center justify-center"
              aria-label="Scroll smoothly back to top of LeadScribe"
            >
              <ArrowUp className="h-4 w-4 group-hover:-translate-y-0.5 transition-transform" />
            </button>

          </div>

        </div>

      </div>
    </footer>
  );
}
