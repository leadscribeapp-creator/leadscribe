import { Sparkles, BarChart3, Zap, Mail, TrendingUp, Users } from "lucide-react";

export default function Features() {
  const list = [
    {
      title: "AI Message Generation",
      desc: "Generate hyper-personalized cold emails, LinkedIn messages, and follow-ups instantly based on target profile research.",
      icon: <Sparkles className="h-6 w-6 text-[#6C63FF]" />,
      badge: "Best Seller"
    },
    {
      title: "Lead Management CRM",
      desc: "Track every lead, their sales status, and conversation histories in one place. No extra spreadsheets required.",
      icon: <BarChart3 className="h-6 w-6 text-[#00D4FF]" />
    },
    {
      title: "Bulk Outreach",
      desc: "Process hundreds of target leads simultaneously. Our AI writes completely custom, separate messages for each one.",
      icon: <Zap className="h-6 w-6 text-[#FFD700]" />,
      badge: "Popular"
    },
    {
      title: "Multi-Channel Support",
      desc: "Ready to launch tailored playbooks for email, LinkedIn connect notes, WhatsApp scripts, or any other outreach format.",
      icon: <Mail className="h-6 w-6 text-[#00D4FF]" />
    },
    {
      title: "Analytics Dashboard",
      desc: "Track critical open rates, reply speeds, and conversion booking metrics in intuitive real-time graphical logs.",
      icon: <TrendingUp className="h-6 w-6 text-[#00C896]" />
    },
    {
      title: "Team Collaboration",
      desc: "Invite teammates, assign lead blocks to individual agents, review team progress, and maximize conversions together.",
      icon: <Users className="h-6 w-6 text-[#6C63FF]" />
    }
  ];

  return (
    <section id="features" className="py-24 md:py-32 bg-[#0A0A0F] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        
        {/* Section header */}
        <div className="max-w-3xl mx-auto text-center mb-20 scroll-reveal">
          <span className="text-xs font-bold tracking-widest text-[#00D4FF] uppercase px-3 py-1 rounded-full bg-[#00D4FF]/10 mb-4 inline-block">
            SaaS Utilities
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mt-1 mb-5">
            Everything You Need to Scale Outreach
          </h2>
          <p className="text-[#8B8B9E] text-base sm:text-lg">
            Built to work right out of the box with CRM systems, email clients, and your workflow. Write less outbound garbage, book far more revenue.
          </p>
        </div>

        {/* Features 2x3 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {list.map((item, idx) => (
            <div
              key={idx}
              className="gradient-border-hover bg-[#16161F]/40 p-8 rounded-2xl flex flex-col justify-between group transition-all duration-300 hover:translate-y-[-8px] scroll-reveal"
              style={{ transitionDelay: `${idx * 100}ms` }}
            >
              <div>
                
                {/* Header Row: Icon and Badge */}
                <div className="flex items-center justify-between mb-6">
                  <div className="h-12 w-12 rounded-xl bg-[#1D1D2C] flex items-center justify-center border border-white/5 shadow-md group-hover:bg-[#6C63FF]/10 group-hover:border-[#6C63FF]/30 transition-all duration-300">
                    {item.icon}
                  </div>
                  {item.badge && (
                    <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-[#6C63FF] bg-[#6C63FF]/10 py-1 px-2.5 rounded-full border border-[#6C63FF]/20">
                      {item.badge}
                    </span>
                  )}
                </div>

                {/* Text Content */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#00D4FF] transition-colors">
                  {item.title}
                </h3>
                
                <p className="text-[#8B8B9E] text-sm leading-relaxed">
                  {item.desc}
                </p>

              </div>

              {/* Action hint link */}
              <div className="mt-8 flex items-center gap-1 text-[#6C63FF] text-xs font-bold tracking-wider uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span>Learn more</span>
                <span>→</span>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
