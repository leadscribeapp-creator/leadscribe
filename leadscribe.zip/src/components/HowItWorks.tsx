import { UserPlus, Sparkles, Send } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      number: "01",
      title: "Add Your Lead",
      description: "Enter the company name, industry, and contact details into LeadScribe's simple interface.",
      icon: <UserPlus className="h-6 w-6 text-[#6C63FF]" />,
      color: "from-[#6C63FF]/20 to-[#6C63FF]/5",
      glow: "rgba(108, 99, 255, 0.15)"
    },
    {
      number: "02",
      title: "AI Writes the Message",
      description: "Our AI analyzes the prospect's background, context, and crafts a 100% personalized outreach message in seconds.",
      icon: <Sparkles className="h-6 w-6 text-[#00D4FF]" />,
      color: "from-[#00D4FF]/20 to-[#00D4FF]/5",
      glow: "rgba(0, 212, 255, 0.15)"
    },
    {
      number: "03",
      title: "Send & Close",
      description: "Review, approve, and send your message. Track responses and watch your leads turn into paying customers.",
      icon: <Send className="h-6 w-6 text-[#00C896]" />,
      color: "from-[#00C896]/20 to-[#00C896]/5",
      glow: "rgba(0, 200, 150, 0.15)"
    }
  ];

  return (
    <section id="about" className="py-24 md:py-32 bg-[#111118]/40 relative overflow-hidden">
      
      {/* Radial overlay */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-[#6C63FF]/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        
        {/* Header content */}
        <div className="text-center max-w-3xl mx-auto mb-20 scroll-reveal">
          <span className="text-xs font-bold tracking-widest text-[#6C63FF] uppercase px-3 py-1 rounded-full bg-[#6C63FF]/10 mb-4 inline-block">
            Outreach Blueprint
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mt-1 mb-5">
            From Lead to Message in 60 Seconds
          </h2>
          <p className="text-[#8B8B9E] text-base sm:text-lg">
            Say goodbye to generalized templates. LeadScribe automates precision research and writes tailored outreach that drives responses.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
          
          {/* Connecting Lines for Desktop */}
          <div className="hidden md:block absolute top-[68px] left-[15%] right-[15%] h-0.5 border-t-2 border-dashed border-white/5 z-0"></div>

          {steps.map((step, idx) => (
            <div
              key={idx}
              className="relative flex flex-col items-center text-center p-8 rounded-2xl bg-[#16161F]/65 border border-white/5 scroll-reveal hover:scale-[1.02] transition-all duration-300 md:z-10 group"
              style={{ transitionDelay: `${idx * 150}ms` }}
            >
              
              {/* Massive floating background index background */}
              <div className="absolute top-2 right-6 text-7xl font-black text-white/[0.02] select-none font-mono tracking-tighter">
                {step.number}
              </div>

              {/* Icon Ring with specific soft glow */}
              <div
                className={`h-14 w-14 bg-gradient-to-b ${step.color} rounded-2xl flex items-center justify-center mb-6 border border-white/10 relative shadow-inner`}
                style={{ boxShadow: `0 0 25px ${step.glow}` }}
              >
                {step.icon}
                
                {/* Micro badge of step index */}
                <span className="absolute -top-1.5 -right-1.5 h-5 w-5 bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] rounded-full text-[10px] font-mono font-bold text-white flex items-center justify-center shadow-lg">
                  {step.number}
                </span>
              </div>

              {/* Title */}
              <h3 className="text-xl font-bold text-white mb-3 group-hover:text-white transition-colors">
                {step.title}
              </h3>

              {/* Description */}
              <p className="text-[#8B8B9E] text-sm leading-relaxed max-w-xs">
                {step.description}
              </p>
              
              {/* Connected by animated mini dot bar */}
              <div className="w-8 h-1 bg-gradient-to-r from-[#6C63FF] to-[#00D4FF] rounded-full mt-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

            </div>
          ))}

        </div>

      </div>
    </section>
  );
}
