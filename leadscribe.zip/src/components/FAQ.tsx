import { useState } from "react";
import { ChevronDown, HelpCircle } from "lucide-react";

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0); // Default open first Q

  const items = [
    {
      q: "Is there a free trial?",
      a: "Yes! We offer a full-featured 14-day free trial. No credit card required to start, and you get complete access to test message generation."
    },
    {
      q: "How does the AI personalize messages?",
      a: "Our AI analyzes the company name, industry, product space, and any contextual information you upload to write hyper-specific, highly personalized outreach sequences tailored exclusively for each lead."
    },
    {
      q: "Can I cancel anytime?",
      a: "Absolutely. LeadScribe is a monthly subscription, meaning no long-term locks or contracts. You can easily upgrade, downgrade, or cancel your account directly from your settings panel anytime."
    },
    {
      q: "What languages does LeadScribe support?",
      a: "Currently, LeadScribe fully supports high-converting English and Arabic outreach generation, with more languages (Spanish, French, German) currently in beta testing."
    },
    {
      q: "Do I need technical skills?",
      a: "Not at all. LeadScribe is carefully crafted to be extremely straightforward and easy to use. If you can fill out a basic form or copy-paste text, you can start writing 10x higher quality campaign emails."
    }
  ];

  const handleToggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-24 md:py-32 bg-[#111118]/40 border-t border-b border-white/5 relative overflow-hidden">
      {/* Background soft glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#6C63FF]/5 rounded-full blur-[110px] pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        
        {/* Header section */}
        <div className="text-center mb-16 scroll-reveal">
          <span className="text-xs font-bold tracking-widest text-[#00D4FF] uppercase px-3 py-1 rounded-full bg-[#00D4FF]/10 mb-4 inline-block">
            Information Center
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mt-1 mb-5">
            Frequently Asked Questions
          </h2>
          <p className="text-[#8B8B9E] text-sm sm:text-base max-w-xl mx-auto">
            Everything you need to know about getting started, managing billing, and scaling outreach copy with LeadScribe.
          </p>
        </div>

        {/* Accordions */}
        <div className="space-y-4">
          {items.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all duration-300 scroll-reveal ${
                  isOpen
                    ? "bg-[#16161F] border-[#6C63FF]/30 shadow-lg shadow-[#000000]/30"
                    : "bg-[#16161F]/40 border-white/5 hover:border-white/10"
                }`}
                style={{ transitionDelay: `${idx * 100}ms` }}
              >
                
                {/* Accordion Trigger */}
                <button
                  onClick={() => handleToggle(idx)}
                  className="w-full text-left px-6 py-5 sm:px-8 sm:py-6 flex items-center justify-between gap-4 focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <div className="flex items-center gap-3.5">
                    <HelpCircle className={`h-5 w-5 shrink-0 transition-colors duration-200 ${isOpen ? "text-[#00D4FF]" : "text-white/30"}`} />
                    <span className="text-white hover:text-white font-semibold text-base sm:text-lg tracking-tight">
                      {item.q}
                    </span>
                  </div>
                  <div
                    className={`h-7 w-7 rounded-lg bg-white/5 flex items-center justify-center text-[#8B8B9E] transition-all duration-300 ${
                      isOpen ? "rotate-180 bg-[#6C63FF]/20 text-[#6C63FF]" : ""
                    }`}
                  >
                    <ChevronDown className="h-4 w-4" />
                  </div>
                </button>

                {/* Accordion Content with smooth height transition */}
                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${
                    isOpen ? "max-h-56 border-t border-white/5 opacity-100" : "max-h-0 opacity-0 pointer-events-none"
                  }`}
                >
                  <div className="px-6 py-5 sm:px-8 sm:py-6 text-[#8B8B9E] text-sm leading-relaxed font-normal">
                    {item.a}
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
