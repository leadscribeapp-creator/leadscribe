import { useState, FormEvent } from "react";
import { ArrowRight, Sparkles, CheckCircle2 } from "lucide-react";

export default function FinalCTA() {
  const [email, setEmail] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes("@")) {
      alert("Please enter a valid business email address.");
      return;
    }
    
    // Animate success states
    setSuccess(true);
    
    // Redirect to hello@leadscribe.app mailto proxy
    setTimeout(() => {
      window.location.href = `mailto:hello@leadscribe.app?subject=LeadScribe%20Outreach%20Signup&body=Hello%20LeadScribe%2C%0A%0AI'd%20like%20to%20register%20free%20for%20LeadScribe%20using%20my%20business%20email%3A%20${encodeURIComponent(
        email
      )}%0A%0AThank%20you!`;
      setEmail("");
      setSuccess(false);
    }, 1500);
  };

  return (
    <section className="py-24 relative overflow-hidden bg-[#0A0A0F]">
      
      {/* Background radial soft light blobs */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[550px] h-[550px] bg-[#6C63FF]/10 rounded-full blur-[110px] pointer-events-none"></div>
      <div className="absolute -bottom-12 right-1/4 w-[450px] h-[450px] bg-[#00D4FF]/10 rounded-full blur-[90px] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-6 md:px-12 relative z-10 scroll-reveal">
        
        {/* Glow Container Panel */}
        <div className="relative rounded-3xl p-10 md:p-20 overflow-hidden text-center bg-gradient-to-br from-[#6C63FF] to-[#00D4FF] shadow-[0_20px_50px_rgba(108,99,255,0.35)]">
          
          {/* Wave mesh texture on top */}
          <div className="absolute inset-0 bg-black/10 mix-blend-overlay opacity-30 pointer-events-none"></div>
          
          <div className="relative z-10 max-w-3xl mx-auto">
            
            {/* Sparkle pill design */}
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-black/15 backdrop-blur-md mb-6 border border-white/10 select-none">
              <Sparkles className="h-4 w-4 text-white fill-white/20 animate-pulse" />
              <span className="text-xs font-bold tracking-wider uppercase text-white">READY TO DOMINATE OUTBOUND</span>
            </div>

            {/* Main title */}
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-[1.1] mb-6">
              Ready to 10x Your Outreach?
            </h2>

            {/* Subtitle */}
            <p className="text-white/80 text-base sm:text-lg md:text-xl font-normal max-w-xl mx-auto mb-10 leading-relaxed">
              Join hundreds of high-performing businesses already using LeadScribe to close more deals.
            </p>

            {/* Form */}
            {!success ? (
              <form
                onSubmit={handleSubmit}
                className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto mb-8 bg-black/15 p-2 rounded-2xl md:rounded-full border border-white/10 backdrop-blur-sm"
              >
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your work email..."
                  required
                  className="w-full bg-transparent px-5 py-3 text-white text-sm outline-none placeholder-white/50 border-none rounded-xl"
                />
                <button
                  type="submit"
                  className="w-full sm:w-auto shrink-0 bg-white text-[#6C63FF] hover:bg-[#F2F0FF] font-bold text-sm px-6 py-3.5 rounded-xl md:rounded-full flex items-center justify-center gap-2 transition-all duration-300 hover:scale-105 shadow-md"
                >
                  Get Started Free
                  <ArrowRight className="h-4 w-4 text-[#6C63FF]" />
                </button>
              </form>
            ) : (
              <div className="max-w-md mx-auto mb-8 p-4 bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl flex items-center justify-center gap-3 text-white animate-pulse">
                <CheckCircle2 className="h-5 w-5 text-white animate-bounce" />
                <span className="text-sm font-bold">Inbound request ready! Opening Mail App...</span>
              </div>
            )}

            {/* Benefits Footer details */}
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-white/70 text-xs md:text-sm font-semibold select-none">
              <span>✓ No credit card required</span>
              <span className="hidden sm:inline">•</span>
              <span>✓ Free 14-day trial</span>
              <span className="hidden sm:inline">•</span>
              <span>✓ Instant campaign setup</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
